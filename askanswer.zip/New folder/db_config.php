<?php
$servername = "localhost";
$username = "ad_user";
$password = "ad_password";
$dbname = "askanswer";
?>